import { Groq } from 'groq-sdk';
const groq = new Groq({ apiKey: process.env.API_KEY });

export const handler = async (event) => {

    try {
        if (!event.body) {
            throw error("No File Uploaded")
        }

        const fileContent = Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf8');
        const csvData = await parseCSV(fileContent);
        const prompt = createPromptFromCSV(csvData);
        const summary = await getGroqSummary(prompt);
        return {
            statusCode: 200,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: 'CSV processed successfully',
              summary: summary,
            })
        };

    }catch(error){
        return {
            statusCode: 400,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ error: error.message })
        };
    }
};

function parseCSV(fileContent) {
    return new Promise((resolve, reject) => {
      const results = [];
      const bufferStream = new stream.PassThrough();
      bufferStream.end(fileContent);
      
      bufferStream
        .pipe(csv())
        .on('data', (data) => results.push(data))
        .on('end', () => resolve(results))
        .on('error', (error) => reject(error));
    });
  }

  function createPromptFromCSV(csvData) {
    const rows = csvData.map(row => 
      JSON.stringify(row)
    ).join('\n');
    
    return `
        
      I have a CSV file that I converted into a string format. I want you to process the rows and return a summary in a json format.
      CSV ROWS:
      ${rows}
    `;
  }

  async function getGroqSummary(prompt) {
    const chatCompletion = await groq.chat.completions.create({
      messages: [
        {
            role: "system",
            content: "You are a CSV summarizing agent. You must convert provided rows into a json format"
        },
        {
          role: "user",
          content: prompt
        }
      ],
      model: "mixtral-8x7b-32768",
      response_format: { type: "json_object" }
    });
    
    try {
      return JSON.parse(chatCompletion.choices[0]?.message?.content || '{}');
    } catch (e) {
      console.error('Failed to parse Groq response:', e);
      return { error: 'Failed to parse AI response' };
    }
  }




const getResponse = async (promp) =>{
    await groq.chat.completions
    .create({
        messages: [
            {
                role: "user",
                content: prompt,
            },
        ],
        model: "llama-3.3-70b-versatile",
    })
    .then((chatCompletion) => {
        response = chatCompletion.choices[0]?.message?.content || "";
    });

    return response
}

